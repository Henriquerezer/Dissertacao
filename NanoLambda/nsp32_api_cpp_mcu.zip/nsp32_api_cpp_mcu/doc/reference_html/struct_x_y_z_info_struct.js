var struct_x_y_z_info_struct =
[
    [ "IntegrationTime", "struct_x_y_z_info_struct.html#a86d0f2840dd8f20d7c8574215bfecbd6", null ],
    [ "IsSaturated", "struct_x_y_z_info_struct.html#a32dc8f6c0a89d17366e232069497bf50", null ],
    [ "X", "struct_x_y_z_info_struct.html#a22442494df9d420e524f58246495d22f", null ],
    [ "Y", "struct_x_y_z_info_struct.html#a09a522684d684505dfcf504875d4c5e5", null ],
    [ "Z", "struct_x_y_z_info_struct.html#a239cef74755f4f3d2f6c346eace0b996", null ]
];