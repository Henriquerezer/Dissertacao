var annotated_dup =
[
    [ "NanoLambdaNSP32", null, [
      [ "IMcuAdaptor", "class_nano_lambda_n_s_p32_1_1_i_mcu_adaptor.html", "class_nano_lambda_n_s_p32_1_1_i_mcu_adaptor" ],
      [ "NSP32", "class_nano_lambda_n_s_p32_1_1_n_s_p32.html", "class_nano_lambda_n_s_p32_1_1_n_s_p32" ],
      [ "TemplateAdaptor", "class_nano_lambda_n_s_p32_1_1_template_adaptor.html", "class_nano_lambda_n_s_p32_1_1_template_adaptor" ]
    ] ],
    [ "SpectrumInfoStruct", "struct_spectrum_info_struct.html", "struct_spectrum_info_struct" ],
    [ "WavelengthInfoStruct", "struct_wavelength_info_struct.html", "struct_wavelength_info_struct" ],
    [ "XYZInfoStruct", "struct_x_y_z_info_struct.html", "struct_x_y_z_info_struct" ]
];