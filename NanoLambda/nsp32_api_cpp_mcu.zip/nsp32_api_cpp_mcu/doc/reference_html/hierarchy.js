var hierarchy =
[
    [ "NanoLambdaNSP32::IMcuAdaptor", "class_nano_lambda_n_s_p32_1_1_i_mcu_adaptor.html", [
      [ "NanoLambdaNSP32::TemplateAdaptor", "class_nano_lambda_n_s_p32_1_1_template_adaptor.html", null ]
    ] ],
    [ "NanoLambdaNSP32::NSP32", "class_nano_lambda_n_s_p32_1_1_n_s_p32.html", null ],
    [ "SpectrumInfoStruct", "struct_spectrum_info_struct.html", null ],
    [ "WavelengthInfoStruct", "struct_wavelength_info_struct.html", null ],
    [ "XYZInfoStruct", "struct_x_y_z_info_struct.html", null ]
];