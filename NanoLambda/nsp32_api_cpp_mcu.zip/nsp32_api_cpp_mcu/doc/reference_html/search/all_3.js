var searchData=
[
  ['datachannelenum',['DataChannelEnum',['../class_nano_lambda_n_s_p32_1_1_n_s_p32.html#a58260eb1427dfcdc9b4ea22388a1b2a3',1,'NanoLambdaNSP32::NSP32']]]
];
