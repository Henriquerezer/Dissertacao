var searchData=
[
  ['init',['Init',['../class_nano_lambda_n_s_p32_1_1_n_s_p32.html#a025d73141bd184bc501d1480a96dfc30',1,'NanoLambdaNSP32::NSP32']]],
  ['isactive',['IsActive',['../class_nano_lambda_n_s_p32_1_1_n_s_p32.html#ab23fa6f743866947eb2d64ef44b8e21d',1,'NanoLambdaNSP32::NSP32']]]
];
