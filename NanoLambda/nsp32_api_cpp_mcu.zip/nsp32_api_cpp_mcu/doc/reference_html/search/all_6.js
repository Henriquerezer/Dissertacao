var searchData=
[
  ['getreturnpacketptr',['GetReturnPacketPtr',['../class_nano_lambda_n_s_p32_1_1_n_s_p32.html#aba4ab1a7247dfa50ae6c8f5fa4288b3f',1,'NanoLambdaNSP32::NSP32']]],
  ['getreturnpacketsize',['GetReturnPacketSize',['../class_nano_lambda_n_s_p32_1_1_n_s_p32.html#ae505f21f4eaab42210a3869636df1823',1,'NanoLambdaNSP32::NSP32']]],
  ['getsensorid',['GetSensorId',['../class_nano_lambda_n_s_p32_1_1_n_s_p32.html#a81d00932b2879a20e7e2d2acc022642d',1,'NanoLambdaNSP32::NSP32']]],
  ['getwavelength',['GetWavelength',['../class_nano_lambda_n_s_p32_1_1_n_s_p32.html#a1415c99380a107e85869af2908a21d95',1,'NanoLambdaNSP32::NSP32']]]
];
