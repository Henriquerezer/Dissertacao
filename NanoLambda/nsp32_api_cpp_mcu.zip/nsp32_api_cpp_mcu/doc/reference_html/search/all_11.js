var searchData=
[
  ['z',['Z',['../struct_spectrum_info_struct.html#a7a49c03c345a1221b019975f85f18726',1,'SpectrumInfoStruct::Z()'],['../struct_x_y_z_info_struct.html#a239cef74755f4f3d2f6c346eace0b996',1,'XYZInfoStruct::Z()']]]
];
