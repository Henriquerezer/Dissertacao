var searchData=
[
  ['y',['Y',['../struct_spectrum_info_struct.html#a5d89921336f6b161d2d8141c333d2f78',1,'SpectrumInfoStruct::Y()'],['../struct_x_y_z_info_struct.html#a09a522684d684505dfcf504875d4c5e5',1,'XYZInfoStruct::Y()']]]
];
