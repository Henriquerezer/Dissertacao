var searchData=
[
  ['templateadaptor',['TemplateAdaptor',['../class_nano_lambda_n_s_p32_1_1_template_adaptor.html',1,'NanoLambdaNSP32::TemplateAdaptor'],['../class_nano_lambda_n_s_p32_1_1_template_adaptor.html#a76c5cda3fc3fabb6ed193efa473e47d7',1,'NanoLambdaNSP32::TemplateAdaptor::TemplateAdaptor(uint32_t gpioPinRst)'],['../class_nano_lambda_n_s_p32_1_1_template_adaptor.html#aec4740b2e7ae46e98abd1153bd532406',1,'NanoLambdaNSP32::TemplateAdaptor::TemplateAdaptor(uint32_t gpioPinRst, NSP32::UartBaudRateEnum baudRate)']]]
];
