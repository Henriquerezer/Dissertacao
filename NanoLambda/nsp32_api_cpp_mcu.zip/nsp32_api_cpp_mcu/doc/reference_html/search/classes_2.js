var searchData=
[
  ['spectruminfostruct',['SpectrumInfoStruct',['../struct_spectrum_info_struct.html',1,'']]]
];
