var searchData=
[
  ['numofpoints',['NumOfPoints',['../struct_spectrum_info_struct.html#a852b5339ba7c9e5699ea65bcdd8ae064',1,'SpectrumInfoStruct::NumOfPoints()'],['../struct_wavelength_info_struct.html#af6b4410d707b52424781390de13b1444',1,'WavelengthInfoStruct::NumOfPoints()']]]
];
