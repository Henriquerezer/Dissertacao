var struct_spectrum_info_struct =
[
    [ "IntegrationTime", "struct_spectrum_info_struct.html#a6bd8d548fbf6a1714607c7883023f6e2", null ],
    [ "IsSaturated", "struct_spectrum_info_struct.html#a3a36ec5342c05c4bbbce4296ecf39bef", null ],
    [ "NumOfPoints", "struct_spectrum_info_struct.html#a852b5339ba7c9e5699ea65bcdd8ae064", null ],
    [ "Spectrum", "struct_spectrum_info_struct.html#afbecebbe4f7aa7cbcd011c746707bbaf", null ],
    [ "X", "struct_spectrum_info_struct.html#a06f62e0d145f8ae08725337df7ebd7bd", null ],
    [ "Y", "struct_spectrum_info_struct.html#a5d89921336f6b161d2d8141c333d2f78", null ],
    [ "Z", "struct_spectrum_info_struct.html#a7a49c03c345a1221b019975f85f18726", null ]
];