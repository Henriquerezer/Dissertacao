/*
 * Copyright (C) 2019 nanoLambda, Inc.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "nrf_gpio.h"
#include "nrf_delay.h"
#include "nrfx_spim.h"
#include "nRF52Adaptor.h"

#define SPIM_INSTANCE	NRF_SPIM0	// use SPIM0

using namespace NanoLambdaNSP32;

/**
 * constructor (for data channel == SPI)
 * @param spiPinSck SPI SCK pin No.
 * @param spiPinMiso SPI MISO pin No.
 * @param spiPinMosi SPI MOSI pin No.
 * @param spiPinCsn SPI CSN pin No.
 * @param gpioPinRst reset pin No. (GPIO pin to reset NSP32)
 */
nRF52Adaptor::nRF52Adaptor(uint32_t spiPinSck, uint32_t spiPinMiso, uint32_t spiPinMosi, uint32_t spiPinCsn, uint32_t gpioPinRst)
	: m_gpioPinRst(gpioPinRst)
{
	m_spiControl.p_reg			= SPIM_INSTANCE;
	m_spiControl.drv_inst_idx	= NRFX_SPIM0_INST_IDX;

	m_spiConfig.ss_pin			= spiPinCsn;
	m_spiConfig.miso_pin		= spiPinMiso;
	m_spiConfig.mosi_pin		= spiPinMosi;
	m_spiConfig.sck_pin			= spiPinSck;
	m_spiConfig.frequency		= NRF_SPIM_FREQ_2M;

	m_spiConfig.ss_active_high	= false;
	m_spiConfig.irq_priority	= NRFX_SPIM_DEFAULT_CONFIG_IRQ_PRIORITY;
	m_spiConfig.orc				= 0xFF;
	m_spiConfig.mode			= NRF_SPIM_MODE_0;
	m_spiConfig.bit_order		= NRF_SPIM_BIT_ORDER_MSB_FIRST;
}

/**
 * initialize adaptor
 */
void nRF52Adaptor::Init()
{
	nrfx_spim_init(&m_spiControl, &m_spiConfig, NULL, NULL);

	nrf_gpio_pin_set(m_spiConfig.ss_pin);	// SPI SS high
	nrf_gpio_cfg_output(m_spiConfig.ss_pin);
	
	nrf_spim_disable(SPIM_INSTANCE);		// disable SPI for power saving
}

/**
 * delay microseconds
 * @param us microseconds
 */
void nRF52Adaptor::DelayMicros(uint32_t us)
{
	nrf_delay_us(us);
}

/**
 * delay milliseconds
 * @param ms milliseconds
 */
void nRF52Adaptor::DelayMillis(uint32_t ms)
{
	nrf_delay_ms(ms);
}

/**
 * set the reset pin (to reset NSP32) to output mode and set "low"
 */
void nRF52Adaptor::PinRstOutputLow()
{
	nrf_gpio_cfg_output(m_gpioPinRst);
	nrf_gpio_pin_clear(m_gpioPinRst);
}

/**
 * set the reset pin (to reset NSP32) "high" and set it to input mode
 */
void nRF52Adaptor::PinRstHighInput()
{
	nrf_gpio_pin_set(m_gpioPinRst);
	nrf_gpio_cfg_default(m_gpioPinRst);
}

/**
 * send through SPI (only used when data channel is SPI)
 * @param pBuf buffer to send
 * @param len data length
 */
void nRF52Adaptor::SpiSend(uint8_t *pBuf, uint32_t len)
{
	uint32_t bytesToTx;

	nrf_spim_frequency_set(SPIM_INSTANCE, NRF_SPIM_FREQ_2M);	// set SPI baud rate = 2Mbits/s
	nrf_spim_enable(SPIM_INSTANCE);								// enable SPI
	nrf_gpio_pin_clear(m_spiConfig.ss_pin);						// SPI SS low

	while(len > 0)
	{
		// if data length exceeds SpiTransferMaxLength, we have to split it and transmit multiple times
		bytesToTx = (len > SpiTransferMaxLength) ? SpiTransferMaxLength : len;

		// SPI send
		nrfx_spim_xfer_desc_t spiXfer;
		spiXfer.p_tx_buffer		= pBuf;
		spiXfer.tx_length		= bytesToTx;
		spiXfer.p_rx_buffer		= 0;
		spiXfer.rx_length		= 0;
		nrfx_spim_xfer(&m_spiControl, &spiXfer, 0);
		
		len -= bytesToTx;
		pBuf += bytesToTx;				
	}

	nrf_gpio_pin_set(m_spiConfig.ss_pin);	// SPI SS high
	nrf_spim_disable(SPIM_INSTANCE);		// disable SPI for power saving
}

/**
 * receive from SPI (only used when data channel is SPI)
 * @param pBuf buffer to receive
 * @param len data length
 */
void nRF52Adaptor::SpiReceive(uint8_t *pBuf, uint32_t len)
{
	uint32_t bytesToRx;

	nrf_spim_frequency_set(SPIM_INSTANCE, NRF_SPIM_FREQ_4M);	// set SPI baud rate = 4Mbits/s
	nrf_spim_enable(SPIM_INSTANCE);								// enable SPI
	nrf_gpio_pin_clear(m_spiConfig.ss_pin);						// SPI SS low

	while(len > 0)
	{
		// if data length exceeds SpiTransferMaxLength, we have to split it and receive multiple times
		bytesToRx = (len > SpiTransferMaxLength) ? SpiTransferMaxLength : len;

		// SPI receive
		nrfx_spim_xfer_desc_t spiXfer;
		spiXfer.p_tx_buffer		= 0;
		spiXfer.tx_length		= 0;
		spiXfer.p_rx_buffer		= pBuf;
		spiXfer.rx_length		= bytesToRx;
		nrfx_spim_xfer(&m_spiControl, &spiXfer, 0);
		
		len -= bytesToRx;
		pBuf += bytesToRx;				
	}

	nrf_gpio_pin_set(m_spiConfig.ss_pin);	// SPI SS high
	nrf_spim_disable(SPIM_INSTANCE);		// disable SPI for power saving
}

/**
 * start to count milliseconds (only used when data channel is UART)
 */
void nRF52Adaptor::StartMillis()
{
	// ***** no need to implement if not using UART channel *****
}

/**
 * get milliseconds passed since last call to StartMillis() (only used when data channel is UART)
 * @return milliseconds passed
 */
uint32_t nRF52Adaptor::GetMillisPassed()
{
	// ***** no need to implement if not using UART channel *****
	return 0;
}

/**
 * see if any bytes available for reading from UART (only used when data channel is UART)
 * @return true for bytes available; false for none
 */
bool nRF52Adaptor::UartBytesAvailable()
{
	// ***** no need to implement if not using UART channel *****
	return false;
}

/**
 * read a single byte from UART (only used when data channel is UART)
 * @return single byte reading from UART
 */
uint8_t nRF52Adaptor::UartReadByte()
{
	// ***** no need to implement if not using UART channel *****
	return 0;
}

/**
 * send through UART (only used when data channel is UART)
 * @param pBuf buffer to send
 * @param len data length
 */
void nRF52Adaptor::UartSend(uint8_t *pBuf, uint32_t len)
{
	// ***** no need to implement if not using UART channel *****
}
