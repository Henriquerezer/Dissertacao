﻿-----------------------------------
Arduino
-----------------------------------
- Introduction
	There are two examples on Arduino.
		1. Beginner
			A clean and simple example for beginners to start with NSP32. We'll demonstrate the basic usage of our API.
		2. ConsoleDemo
			A console program to demonstrate full functionalities of NSP32. Users can operate NSP32 by interactive console commands.

- *** hardware photos, screen shots ***

- Tested on
	Arduino Uno
	*** other Arduino board type ***

- Hardware Setup
	The following tables show the recommended pin connections between NSP32 and the Arduino board.

	1. VDD and GND
		Note: On Arduino, choose the GND closest to 3V3.
	
		-----------------------------------------------------------------
		              NSP32         Arduino       Arduino       Arduino   
		                            Uno/101       Mega          Nano v3 
		Power         Pin           Pin           Pin           Pin     
		-----------------------------------------------------------------
		              VDD3V3        3V3           3V3           3V3
		              GND           GND           GND           GND
		
	2. SPI signals (when data channel is SPI)
		Note: NSP32 voltage level is 3.3V. A level-shift circuit might be needed if your Arduino runs at 5V.

		-----------------------------------------------------------------
		              NSP32         Arduino       Arduino       Arduino   
		                            Uno/101       Mega          Nano v3 
		SPI Signal    Pin           Pin           Pin           Pin     
		-----------------------------------------------------------------
		Wakeup/Reset  RST           8             49            D8      
		SPI SSEL      SS            10            53            D10     
		SPI MOSI      MOSI          11 / ICSP-4   51            D11     
		SPI MISO      MISO          12 / ICSP-1   50            D12     
		SPI SCK       SCK           13 / ICSP-3   52            D13     
		Ready         Ready         2             21            D2
		
	3. UART signals (when data channel is UART)
		Note: NSP32 voltage level is 3.3V. A level-shift circuit might be needed if your Arduino runs at 5V.

		-----------------------------------------------------------------
		              NSP32         Arduino       Arduino       Arduino   
		                            Uno/101       Mega          Nano v3 
		UART Signal   Pin           Pin           Pin           Pin     
		-----------------------------------------------------------------
		Wakeup/Reset  RST           8             49            D8      
		UART RX       TX            10            53            D10
		BAUD_SEL[0]   BAUD_SEL[0]   11 / ICSP-4   51            D11     UART baud rate select bit0
		BAUD_SEL[1]   BAUD_SEL[1]   12 / ICSP-1   50            D12     UART baud rate select bit1
		UART TX       RX            13 / ICSP-3   52            D13
		Ready         Ready         2             21            D2

	4. If you are using NSP32 DBK board, make sure jumper J3 is ON (short).

- API Source File Location
	Our API source files are put under [/examples/Arduino/NanoLambdaNSP32/src/], along with ArduinoAdaptor.h and ArduinoAdaptor.cpp tailored for Arduino.

- Software Setup
	1. Install Arduino IDE.
	2. Put our [/examples/Arduino/NanoLambdaNSP32] folder under [{sketchbook}/libraries/].
		This will add NanoLambdaNSP32 to Arduino's libraries.
		the {sketchbook} path could be found under Arduino IDE > File > Preferences > Sketchbook location.
	3. Re-open Arduino IDE, the "Beginner" and "ConsoleDemo" examples should appear at File > Examples > NanoLambdaNSP32.

- Customization
	1. According to your Arduino board type, you might need to modify the pin numbers in our example codes.
		For your convenience, we have marked that code section with the title "modify this section to fit your need".
	2. Feel free to modify ArduinoAdaptor.h and ArduinoAdaptor.cpp if needed (although in most cases, you don't have to).

- Run the Example
	To run the examples, upload them to your Arduino board from Arduino IDE.
	Then open "Serial Monitor" in Arduino IDE (make sure the setting is "NL(newline)" and "115200 baud").

	*** operations & behaviors (including the LED status, etc...) ***
	
-----------------------------------
nRF52
-----------------------------------
- Introduction
	The example runs on Nordic nRF52832 SoC. The diagram is as followed:

		NSP32 module <-----> nRF52832 with BLE <-----> Android phone
		               SPI                       BLE

	nRF52832 acts as a forwarder, to forward command packets and return packets between NSP32 module and the Android phone.
	By this way, the Android app can wirelessly (through bluetooth) control NSP32 module and get the spectrum data.

	This example must run in conjunction with "Android SpectrumMeter" example installed on an Android phone.
	You can find that example in our "NSP32 Java API for Android / desktop" download package.
	
	If you are using NSP32 DBK board, this example is preloaded in the on-board nRF52832.

- *** hardware photos, screen shots ***

- Tested on
	nRF52832

- Hardware Setup
	The following tables show the recommended pin connections between NSP32 and nRF52832 (or PCA10040 Development Kit board).

	1. VDD and GND
		---------------------------------------
		              NSP32         nRF52832
		Power         Pin           Pin        
		---------------------------------------
		              VDD3V3        VDD        
		              GND           GND        
		
	2. SPI signals
		---------------------------------------
		              NSP32         nRF52832   
		SPI Signal    Pin           Pin        
		---------------------------------------
		Wakeup/Reset  RST           P0.16
		SPI SSEL      SS            P0.22
		SPI MOSI      MOSI          P0.23
		SPI MISO      MISO          P0.24
		SPI SCK       SCK           P0.25
		Ready         Ready         P0.14

	3. Status LED
		Connect nRF52832 P0.18 to a resistor and a LED as followed.

			[nRF52832 P0.18] ----- [--^^^^^--] ----- [- LED +] ----- [VDD3V3]
			                     1k ohm resistor

	4. If you are using NSP32 DBK board, the above connections are already done. You just need to make sure jumper J3 is OFF (open).

- API Source File Location
	1. Our API source files are put under [/examples/nRF52/SpectrumMeter/NanoLambdaNSP32/], along with nRF52Adaptor.h and nRF52Adaptor.cpp tailored for nRF52.
	2. NSP32CWrapper.h and NSP32CWrapper.c are also provided under the same folder, to enable NSP32 API being called from C source code (i.e. main.c).

- Pre-built hex
	1. A pre-built hex file is located at [/examples/nRF52/SpectrumMeter/pca10040/s132/arm5_no_packs/_build/nrf52832_xxaa.hex].
	2. You can program the hex to nRF52832 by flashers (e.g. nRFgo or J-Flash).
	3. The example requires Nordic SoftDevice present on nRF52832. Make sure you program the "S132 v6.1.0 SoftDevice (provided with nRF SDK 15.2.0)" as well.
	
- Software Setup
	If you need to rebuild the hex file, or want to modify the example code, you can follow these steps:
		1. Install Keil5 IDE.
		2. Download "nRF SDK 15.2.0" and extract it to your hard drive. Say the extracted path is {SDK}.
		3. Put our [/examples/nRF52/SpectrumMeter] folder under [{SDK}/examples/ble_peripheral/].
		4. Open [{SDK}/examples/ble_peripheral/SpectrumMeter/pca10040/s132/arm5_no_packs/image_transfer_demo_pca10040_s132.uvprojx] in Keil5.
		5. Build the project, and you will get the hex file at [{SDK}/examples/ble_peripheral/SpectrumMeter/pca10040/s132/arm5_no_packs/_build/nrf52832_xxaa.hex].

- Project Origin
	1. This example is modified from a demo project from Nordic, which could be found at [https://github.com/NordicPlayground/nrf52-ble-image-transfer-demo].
	2. We try to do minimum modifications and keep the original codes as possible.

- Run the Example
	To run the example, program the hex file and Nordic SoftDevice to nRF52832. Then power on.

	*** operations & behaviors (including the LED status, etc...) ***

	- When BLE is advertising, you shall see the nRF status LED blinking.
	- After Android app connects nRF, the nRF status LED will keep lighting.
	- If the advertising times out (Android app does not connect within 180 seconds), nRF will go system-off. 
		Users need to wake it up through the reset pin or the "power-off -> power-on" procedure.
