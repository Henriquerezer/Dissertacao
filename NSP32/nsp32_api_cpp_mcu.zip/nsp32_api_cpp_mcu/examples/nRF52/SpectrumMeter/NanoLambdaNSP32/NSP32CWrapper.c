/*
 * Copyright (C) 2019 nanoLambda, Inc.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "nRF52Adaptor.h"
#include "NSP32.h"
#include "NSP32CWrapper.h"

using namespace NanoLambdaNSP32;

/***********************************************************************************
 * modify this section to fit your need (e.g. if you are not using PCA10040 board) *
 ***********************************************************************************/

	#if defined(BOARD_PCA10040)
		static nRF52Adaptor adaptor(25, 24, 23, 22, 16);
	#else
		#error Board not defined or not supported
	#endif    
	
	static NSP32 nsp32(&adaptor, NSP32::ChannelSpi);

/***********************************************************************************/

/**
 * initialize NSP32
 */
void NSP32Init(void)
{
	nsp32.Init();
}

/**
 * check if NSP32 is in active mode
 * @return true for active mode; false for standby mode
 */
bool NSP32IsActive(void)
{
	return nsp32.IsActive();
}

/**
 * wakeup/reset NSP32
 */
void NSP32Wakeup(void)
{	
	nsp32.Wakeup();
}

/**
 * say hello to NSP32
 * @param userCode command user code
 */
void NSP32Hello(uint8_t userCode)
{
	nsp32.Hello(userCode);
}

/**
 * standby NSP32
 * @param userCode command user code
 */
void NSP32Standby(uint8_t userCode)
{
	nsp32.Standby(userCode);
}

/**
 * get sensor id
 * @param userCode command user code
 */
void NSP32GetSensorId(uint8_t userCode)
{
	nsp32.GetSensorId(userCode);
}

/**
 * get wavelength
 * @param userCode command user code
 */
void NSP32GetWavelength(uint8_t userCode)
{
	nsp32.GetWavelength(userCode);
}

/**
 * start spectrum acquisition
 * @param userCode command user code
 * @param integrationTime integration time
 * @param frameAvgNum frame average num
 * @param enableAE true to enable AE; false to disable AE
 */
void NSP32AcqSpectrum(uint8_t userCode, uint16_t integrationTime, uint8_t frameAvgNum, bool enableAE)
{
	nsp32.AcqSpectrum(userCode, integrationTime, frameAvgNum, enableAE);
}

/**
 * start XYZ acquisition
 * @param userCode command user code
 * @param integrationTime integration time
 * @param frameAvgNum frame average num
 * @param enableAE true to enable AE; false to disable AE
 */
void NSP32AcqXYZ(uint8_t userCode, uint16_t integrationTime, uint8_t frameAvgNum, bool enableAE)
{
	nsp32.AcqXYZ(userCode, integrationTime, frameAvgNum, enableAE);
}

/**
 * "ready trigger" handler (call this function when master MCU receives a ready trigger on GPIO from NSP32)
 */
void NSP32OnPinReadyTriggered(void)
{
	nsp32.OnPinReadyTriggered();
}

/**
 * update status (including checking async results, and processing forward commands)
 */
void NSP32UpdateStatus(void)
{
	nsp32.UpdateStatus();
}

/**
 * forward a command byte to NSP32 (call this function when master MCU receives a command byte sent from PC/App) (only used when master MCU acts as a forwarder)
 * @param fwd single byte to forward
 */
void NSP32FwdCmdByte(uint8_t fwd)
{
	nsp32.FwdCmdByte(fwd);
}

/**
 * clear return packet
 */
void NSP32ClearReturnPacket(void)
{
	nsp32.ClearReturnPacket();
}

/**
 * get the return packet size
 * @return return packet size (return 0 if the return packet is not yet available or is cleared)
 */
uint32_t NSP32GetReturnPacketSize(void)
{
	return nsp32.GetReturnPacketSize();
}
		
/**
 * get the pointer to the return packet
 * @return pointer to the return packet (return 0 if the return packet is not yet available or is cleared)
 */
uint8_t* NSP32GetReturnPacketPtr(void)
{
	return nsp32.GetReturnPacketPtr();
}

/**
 * extract sensor id string from the return packet ([NOTE]: the string occupies 15 bytes, including the zero terminated byte)
 * @param szStrBuf pointer to the destination string buffer
 */
void NSP32ExtractSensorIdStr(char *szStrBuf)
{
	nsp32.ExtractSensorIdStr(szStrBuf);
}

/**
 * extract wavelength info from the return packet
 * @param pInfo pointer to the wavelength info struct
 */
void NSP32ExtractWavelengthInfo(WavelengthInfo *pInfo)
{
	nsp32.ExtractWavelengthInfo(pInfo);
}

/**
 * extract spectrum info from the return packet
 * @param pInfo pointer to the spectrum info struct
 */
void NSP32ExtractSpectrumInfo(SpectrumInfo *pInfo)
{
	nsp32.ExtractSpectrumInfo(pInfo);
}

/**
 * extract XYZ info from the return packet
 * @param pInfo pointer to the XYZ info struct
 */
void NSP32ExtractXYZInfo(XYZInfo *pInfo)
{
	nsp32.ExtractXYZInfo(pInfo);
}
