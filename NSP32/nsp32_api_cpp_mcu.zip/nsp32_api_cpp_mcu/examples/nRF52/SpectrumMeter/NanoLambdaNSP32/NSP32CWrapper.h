/*
 * Copyright (C) 2019 nanoLambda, Inc.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __NANOLAMBDA_NSP32_NSP32_C_WRAPPER_H
#define __NANOLAMBDA_NSP32_NSP32_C_WRAPPER_H

#include <stdint.h>
#include "WavelengthInfo.h"
#include "SpectrumInfo.h"
#include "XYZInfo.h"

/**
 * These wrapper functions are provided in case you need to use NSP32 API from a C source code instead of a C++ source code.
 */	

#ifdef __cplusplus
extern "C" {
#endif

void NSP32Init(void);						// initialize NSP32
bool NSP32IsActive(void);					// check if NSP32 is in active mode
void NSP32Wakeup(void);						// wakeup/reset NSP32

void NSP32Hello(uint8_t userCode);			// say hello to NSP32
void NSP32Standby(uint8_t userCode);		// standby NSP32
void NSP32GetSensorId(uint8_t userCode);	// get sensor id
void NSP32GetWavelength(uint8_t userCode);	// get wavelength
void NSP32AcqSpectrum(uint8_t userCode, uint16_t integrationTime, uint8_t frameAvgNum, bool enableAE);	// start spectrum acquisition
void NSP32AcqXYZ(uint8_t userCode, uint16_t integrationTime, uint8_t frameAvgNum, bool enableAE);		// start XYZ acquisition

void NSP32OnPinReadyTriggered(void);		// "ready trigger" handler (call this function when master MCU receives a ready trigger on GPIO from NSP32)
void NSP32UpdateStatus(void);				// update status (including checking async results, and processing forward commands)

void NSP32FwdCmdByte(uint8_t fwd);			// forward a command byte to NSP32 (call this function when master MCU receives a command byte sent from PC/App) (only used when master MCU acts as a forwarder)

void NSP32ClearReturnPacket(void);			// clear return package
uint32_t NSP32GetReturnPacketSize(void);	// get the return packet size (return 0 if the return packet is not yet available or is cleared)
uint8_t* NSP32GetReturnPacketPtr(void);		// get the pointer to the return packet (return 0 if the return packet is not yet available or is cleared)

void NSP32ExtractSensorIdStr(char *szStrBuf);			// extract sensor id string from the return packet ([NOTE]: the string occupies 15 bytes, including the zero terminated byte)
void NSP32ExtractWavelengthInfo(WavelengthInfo *pInfo);	// extract wavelength info from the return packet
void NSP32ExtractSpectrumInfo(SpectrumInfo *pInfo);		// extract spectrum info from the return packet
void NSP32ExtractXYZInfo(XYZInfo *pInfo);				// extract XYZ info from the return packet

#ifdef __cplusplus
}
#endif

#endif
