var struct_wavelength_info_struct =
[
    [ "NumOfPoints", "struct_wavelength_info_struct.html#af6b4410d707b52424781390de13b1444", null ],
    [ "Wavelength", "struct_wavelength_info_struct.html#a51a5572313935cbdfe9d57eb6404f001", null ]
];