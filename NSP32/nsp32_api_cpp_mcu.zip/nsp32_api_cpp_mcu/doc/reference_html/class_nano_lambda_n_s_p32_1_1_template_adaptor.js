var class_nano_lambda_n_s_p32_1_1_template_adaptor =
[
    [ "TemplateAdaptor", "class_nano_lambda_n_s_p32_1_1_template_adaptor.html#a76c5cda3fc3fabb6ed193efa473e47d7", null ],
    [ "TemplateAdaptor", "class_nano_lambda_n_s_p32_1_1_template_adaptor.html#aec4740b2e7ae46e98abd1153bd532406", null ]
];