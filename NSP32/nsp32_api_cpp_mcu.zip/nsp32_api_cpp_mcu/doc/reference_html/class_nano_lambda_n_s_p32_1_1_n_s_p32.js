var class_nano_lambda_n_s_p32_1_1_n_s_p32 =
[
    [ "CmdCodeEnum", "class_nano_lambda_n_s_p32_1_1_n_s_p32.html#ae07acc4348aaaa927316e46d0a0425d7", [
      [ "CodeUnknown", "class_nano_lambda_n_s_p32_1_1_n_s_p32.html#ae07acc4348aaaa927316e46d0a0425d7a5aa955c5ea5432ade818e723999c6bd2", null ],
      [ "CodePrefix0", "class_nano_lambda_n_s_p32_1_1_n_s_p32.html#ae07acc4348aaaa927316e46d0a0425d7a8ccea7e6f86b5578634231f70eb487ce", null ],
      [ "CodePrefix1", "class_nano_lambda_n_s_p32_1_1_n_s_p32.html#ae07acc4348aaaa927316e46d0a0425d7ad1196f316a7f683f4b699d6fa37b9933", null ],
      [ "CodeHello", "class_nano_lambda_n_s_p32_1_1_n_s_p32.html#ae07acc4348aaaa927316e46d0a0425d7ad389353e1aa94f3958cfe46aee2093a3", null ],
      [ "CodeStandby", "class_nano_lambda_n_s_p32_1_1_n_s_p32.html#ae07acc4348aaaa927316e46d0a0425d7a85c00cd3f4ef447c4d146d523d6b50c2", null ],
      [ "CodeGetSensorId", "class_nano_lambda_n_s_p32_1_1_n_s_p32.html#ae07acc4348aaaa927316e46d0a0425d7ab91512034ac5a01b2255e1d499682114", null ],
      [ "CodeGetWavelength", "class_nano_lambda_n_s_p32_1_1_n_s_p32.html#ae07acc4348aaaa927316e46d0a0425d7af5b728e4e88b5de82bbcad77670f4831", null ],
      [ "CodeAcqSpectrum", "class_nano_lambda_n_s_p32_1_1_n_s_p32.html#ae07acc4348aaaa927316e46d0a0425d7ad11b6ceaa957a74d82f703cfdd1da2ff", null ],
      [ "CodeGetSpectrum", "class_nano_lambda_n_s_p32_1_1_n_s_p32.html#ae07acc4348aaaa927316e46d0a0425d7a874874d94a82889d6fb7b115521c296b", null ],
      [ "CodeAcqXYZ", "class_nano_lambda_n_s_p32_1_1_n_s_p32.html#ae07acc4348aaaa927316e46d0a0425d7ad99d2b8226f16ccbefa92c6da38f9669", null ],
      [ "CodeGetXYZ", "class_nano_lambda_n_s_p32_1_1_n_s_p32.html#ae07acc4348aaaa927316e46d0a0425d7a6d03e658ae550e35a215659bfd2bd758", null ]
    ] ],
    [ "DataChannelEnum", "class_nano_lambda_n_s_p32_1_1_n_s_p32.html#a58260eb1427dfcdc9b4ea22388a1b2a3", [
      [ "ChannelSpi", "class_nano_lambda_n_s_p32_1_1_n_s_p32.html#a58260eb1427dfcdc9b4ea22388a1b2a3a4acb385777514bd905e009c850ef3dfa", null ],
      [ "ChannelUart", "class_nano_lambda_n_s_p32_1_1_n_s_p32.html#a58260eb1427dfcdc9b4ea22388a1b2a3a05a6b210bbdabb04402273180b06ef3f", null ]
    ] ],
    [ "UartBaudRateEnum", "class_nano_lambda_n_s_p32_1_1_n_s_p32.html#a1601b625f54b4c02b4137c0a1473edad", [
      [ "BaudRate9600", "class_nano_lambda_n_s_p32_1_1_n_s_p32.html#a1601b625f54b4c02b4137c0a1473edadaeab95e4c80fa8df3127db233ac1083a8", null ],
      [ "BaudRate19200", "class_nano_lambda_n_s_p32_1_1_n_s_p32.html#a1601b625f54b4c02b4137c0a1473edada5cf20bafa42b33a882307f4c0dc06fcb", null ],
      [ "BaudRate38400", "class_nano_lambda_n_s_p32_1_1_n_s_p32.html#a1601b625f54b4c02b4137c0a1473edadae34d6c10c90d6ce2e464bafd4704cd9b", null ],
      [ "BaudRate115200", "class_nano_lambda_n_s_p32_1_1_n_s_p32.html#a1601b625f54b4c02b4137c0a1473edada6df7c30171f4a9be913e258262592d0c", null ]
    ] ],
    [ "NSP32", "class_nano_lambda_n_s_p32_1_1_n_s_p32.html#a275bd21650a95ce8c7e1ff17f9c9799e", null ],
    [ "AcqSpectrum", "class_nano_lambda_n_s_p32_1_1_n_s_p32.html#aff2006e826e23cb78fc3ce78f999159e", null ],
    [ "AcqXYZ", "class_nano_lambda_n_s_p32_1_1_n_s_p32.html#a55218593b37a2975c58e39d636e5b68b", null ],
    [ "ClearReturnPacket", "class_nano_lambda_n_s_p32_1_1_n_s_p32.html#a040d5c70da8f9a3efdabac5b290a23d3", null ],
    [ "ExtractSensorIdStr", "class_nano_lambda_n_s_p32_1_1_n_s_p32.html#a6caf875ef660ea5d07b0bc3ac826744d", null ],
    [ "ExtractSpectrumInfo", "class_nano_lambda_n_s_p32_1_1_n_s_p32.html#a354f741f42cc9ec4fc89b37a225fb54b", null ],
    [ "ExtractWavelengthInfo", "class_nano_lambda_n_s_p32_1_1_n_s_p32.html#a1679fe0a7968ae26525f2b9be3979d0e", null ],
    [ "ExtractXYZInfo", "class_nano_lambda_n_s_p32_1_1_n_s_p32.html#ae388702fe6f687b91fc44f63276c1b19", null ],
    [ "FwdCmdByte", "class_nano_lambda_n_s_p32_1_1_n_s_p32.html#a8b360a2252cf25c8a8e7c1a4e7bbe205", null ],
    [ "GetReturnPacketPtr", "class_nano_lambda_n_s_p32_1_1_n_s_p32.html#aba4ab1a7247dfa50ae6c8f5fa4288b3f", null ],
    [ "GetReturnPacketSize", "class_nano_lambda_n_s_p32_1_1_n_s_p32.html#ae505f21f4eaab42210a3869636df1823", null ],
    [ "GetSensorId", "class_nano_lambda_n_s_p32_1_1_n_s_p32.html#a81d00932b2879a20e7e2d2acc022642d", null ],
    [ "GetWavelength", "class_nano_lambda_n_s_p32_1_1_n_s_p32.html#a1415c99380a107e85869af2908a21d95", null ],
    [ "Hello", "class_nano_lambda_n_s_p32_1_1_n_s_p32.html#a59506cc00c2f6a0be49f4e14bb3e9ba7", null ],
    [ "Init", "class_nano_lambda_n_s_p32_1_1_n_s_p32.html#a025d73141bd184bc501d1480a96dfc30", null ],
    [ "IsActive", "class_nano_lambda_n_s_p32_1_1_n_s_p32.html#ab23fa6f743866947eb2d64ef44b8e21d", null ],
    [ "OnPinReadyTriggered", "class_nano_lambda_n_s_p32_1_1_n_s_p32.html#a243d35faf51ecd26ddd4a9d170030560", null ],
    [ "Standby", "class_nano_lambda_n_s_p32_1_1_n_s_p32.html#af23ad36e64b3cf51194d113efc1a98d1", null ],
    [ "UpdateStatus", "class_nano_lambda_n_s_p32_1_1_n_s_p32.html#a40bb84514a1db2fc77147ec8d3a6b4b0", null ],
    [ "Wakeup", "class_nano_lambda_n_s_p32_1_1_n_s_p32.html#a088e7809666477bfe6e7c2ae236d1850", null ]
];