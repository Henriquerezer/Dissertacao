var searchData=
[
  ['updatestatus',['UpdateStatus',['../class_nano_lambda_n_s_p32_1_1_n_s_p32.html#a40bb84514a1db2fc77147ec8d3a6b4b0',1,'NanoLambdaNSP32::NSP32']]]
];
