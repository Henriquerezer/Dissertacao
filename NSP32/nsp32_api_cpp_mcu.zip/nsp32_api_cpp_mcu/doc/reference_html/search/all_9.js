var searchData=
[
  ['nsp32',['NSP32',['../class_nano_lambda_n_s_p32_1_1_n_s_p32.html',1,'NanoLambdaNSP32::NSP32'],['../class_nano_lambda_n_s_p32_1_1_i_mcu_adaptor.html#a1633630e86de3381066bbfdfa547057e',1,'NanoLambdaNSP32::IMcuAdaptor::NSP32()'],['../class_nano_lambda_n_s_p32_1_1_n_s_p32.html#a275bd21650a95ce8c7e1ff17f9c9799e',1,'NanoLambdaNSP32::NSP32::NSP32()']]],
  ['numofpoints',['NumOfPoints',['../struct_spectrum_info_struct.html#a852b5339ba7c9e5699ea65bcdd8ae064',1,'SpectrumInfoStruct::NumOfPoints()'],['../struct_wavelength_info_struct.html#af6b4410d707b52424781390de13b1444',1,'WavelengthInfoStruct::NumOfPoints()']]]
];
