var searchData=
[
  ['clearreturnpacket',['ClearReturnPacket',['../class_nano_lambda_n_s_p32_1_1_n_s_p32.html#a040d5c70da8f9a3efdabac5b290a23d3',1,'NanoLambdaNSP32::NSP32']]]
];
