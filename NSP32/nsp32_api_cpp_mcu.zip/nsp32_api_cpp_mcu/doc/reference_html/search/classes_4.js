var searchData=
[
  ['wavelengthinfostruct',['WavelengthInfoStruct',['../struct_wavelength_info_struct.html',1,'']]]
];
