var indexSectionsWithContent =
{
  0: "abcdefghinostuwxyz",
  1: "instwx",
  2: "acefghinostuw",
  3: "inswxyz",
  4: "cdu",
  5: "bc",
  6: "n"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "enums",
  5: "enumvalues",
  6: "related"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Variables",
  4: "Enumerations",
  5: "Enumerator",
  6: "Friends"
};

