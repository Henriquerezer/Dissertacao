var searchData=
[
  ['standby',['Standby',['../class_nano_lambda_n_s_p32_1_1_n_s_p32.html#af23ad36e64b3cf51194d113efc1a98d1',1,'NanoLambdaNSP32::NSP32']]]
];
