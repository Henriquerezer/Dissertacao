var searchData=
[
  ['baudrate115200',['BaudRate115200',['../class_nano_lambda_n_s_p32_1_1_n_s_p32.html#a1601b625f54b4c02b4137c0a1473edada6df7c30171f4a9be913e258262592d0c',1,'NanoLambdaNSP32::NSP32']]],
  ['baudrate19200',['BaudRate19200',['../class_nano_lambda_n_s_p32_1_1_n_s_p32.html#a1601b625f54b4c02b4137c0a1473edada5cf20bafa42b33a882307f4c0dc06fcb',1,'NanoLambdaNSP32::NSP32']]],
  ['baudrate38400',['BaudRate38400',['../class_nano_lambda_n_s_p32_1_1_n_s_p32.html#a1601b625f54b4c02b4137c0a1473edadae34d6c10c90d6ce2e464bafd4704cd9b',1,'NanoLambdaNSP32::NSP32']]],
  ['baudrate9600',['BaudRate9600',['../class_nano_lambda_n_s_p32_1_1_n_s_p32.html#a1601b625f54b4c02b4137c0a1473edadaeab95e4c80fa8df3127db233ac1083a8',1,'NanoLambdaNSP32::NSP32']]]
];
