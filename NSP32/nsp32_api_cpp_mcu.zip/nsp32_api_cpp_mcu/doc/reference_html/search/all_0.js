var searchData=
[
  ['acqspectrum',['AcqSpectrum',['../class_nano_lambda_n_s_p32_1_1_n_s_p32.html#aff2006e826e23cb78fc3ce78f999159e',1,'NanoLambdaNSP32::NSP32']]],
  ['acqxyz',['AcqXYZ',['../class_nano_lambda_n_s_p32_1_1_n_s_p32.html#a55218593b37a2975c58e39d636e5b68b',1,'NanoLambdaNSP32::NSP32']]]
];
