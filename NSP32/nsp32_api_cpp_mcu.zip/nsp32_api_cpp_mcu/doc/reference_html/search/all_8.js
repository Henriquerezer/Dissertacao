var searchData=
[
  ['imcuadaptor',['IMcuAdaptor',['../class_nano_lambda_n_s_p32_1_1_i_mcu_adaptor.html',1,'NanoLambdaNSP32']]],
  ['init',['Init',['../class_nano_lambda_n_s_p32_1_1_n_s_p32.html#a025d73141bd184bc501d1480a96dfc30',1,'NanoLambdaNSP32::NSP32']]],
  ['integrationtime',['IntegrationTime',['../struct_spectrum_info_struct.html#a6bd8d548fbf6a1714607c7883023f6e2',1,'SpectrumInfoStruct::IntegrationTime()'],['../struct_x_y_z_info_struct.html#a86d0f2840dd8f20d7c8574215bfecbd6',1,'XYZInfoStruct::IntegrationTime()']]],
  ['isactive',['IsActive',['../class_nano_lambda_n_s_p32_1_1_n_s_p32.html#ab23fa6f743866947eb2d64ef44b8e21d',1,'NanoLambdaNSP32::NSP32']]],
  ['issaturated',['IsSaturated',['../struct_spectrum_info_struct.html#a3a36ec5342c05c4bbbce4296ecf39bef',1,'SpectrumInfoStruct::IsSaturated()'],['../struct_x_y_z_info_struct.html#a32dc8f6c0a89d17366e232069497bf50',1,'XYZInfoStruct::IsSaturated()']]]
];
