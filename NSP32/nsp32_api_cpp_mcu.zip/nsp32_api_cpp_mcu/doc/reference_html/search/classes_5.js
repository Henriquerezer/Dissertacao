var searchData=
[
  ['xyzinfostruct',['XYZInfoStruct',['../struct_x_y_z_info_struct.html',1,'']]]
];
