var searchData=
[
  ['integrationtime',['IntegrationTime',['../struct_spectrum_info_struct.html#a6bd8d548fbf6a1714607c7883023f6e2',1,'SpectrumInfoStruct::IntegrationTime()'],['../struct_x_y_z_info_struct.html#a86d0f2840dd8f20d7c8574215bfecbd6',1,'XYZInfoStruct::IntegrationTime()']]],
  ['issaturated',['IsSaturated',['../struct_spectrum_info_struct.html#a3a36ec5342c05c4bbbce4296ecf39bef',1,'SpectrumInfoStruct::IsSaturated()'],['../struct_x_y_z_info_struct.html#a32dc8f6c0a89d17366e232069497bf50',1,'XYZInfoStruct::IsSaturated()']]]
];
