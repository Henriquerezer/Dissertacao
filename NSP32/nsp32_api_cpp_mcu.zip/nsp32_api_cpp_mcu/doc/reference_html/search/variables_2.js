var searchData=
[
  ['spectrum',['Spectrum',['../struct_spectrum_info_struct.html#afbecebbe4f7aa7cbcd011c746707bbaf',1,'SpectrumInfoStruct']]]
];
