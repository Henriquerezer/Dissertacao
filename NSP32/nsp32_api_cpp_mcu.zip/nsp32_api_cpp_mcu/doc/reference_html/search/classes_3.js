var searchData=
[
  ['templateadaptor',['TemplateAdaptor',['../class_nano_lambda_n_s_p32_1_1_template_adaptor.html',1,'NanoLambdaNSP32']]]
];
