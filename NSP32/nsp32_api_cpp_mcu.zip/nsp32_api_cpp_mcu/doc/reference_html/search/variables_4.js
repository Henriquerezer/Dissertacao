var searchData=
[
  ['x',['X',['../struct_spectrum_info_struct.html#a06f62e0d145f8ae08725337df7ebd7bd',1,'SpectrumInfoStruct::X()'],['../struct_x_y_z_info_struct.html#a22442494df9d420e524f58246495d22f',1,'XYZInfoStruct::X()']]]
];
