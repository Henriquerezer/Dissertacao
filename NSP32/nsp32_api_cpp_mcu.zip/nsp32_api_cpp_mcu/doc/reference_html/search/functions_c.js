var searchData=
[
  ['wakeup',['Wakeup',['../class_nano_lambda_n_s_p32_1_1_n_s_p32.html#a088e7809666477bfe6e7c2ae236d1850',1,'NanoLambdaNSP32::NSP32']]]
];
