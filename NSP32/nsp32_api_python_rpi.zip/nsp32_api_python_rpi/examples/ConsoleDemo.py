﻿#
# Copyright (C) 2019 nanoLambda, Inc.
# 
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# 
#     http://www.apache.org/licenses/LICENSE-2.0
# 
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

import traceback
from NanoLambdaNSP32 import *

"""A console program to demonstrate full functionalities of NSP32."""

def main():
	#***********************************************************************************
	# modify this section to fit your need                                             *
	#***********************************************************************************
	
	PinRst		= 13  	# pin Reset (the number is based on GPIO.BOARD)
	PinReady	= 15 	# pin Ready (the number is based on GPIO.BOARD)

	nsp32 = NSP32(PinRst, PinReady, DataChannelEnum.Spi, spiBus = 0, spiDevice = 0)		# use SPI channel
	#nsp32 = NSP32(PinRst, PinReady, DataChannelEnum.Uart, uartPotName = '/dev/ttyS0')	# use UART channel
	
	#***********************************************************************************

	# initialize NSP32
	nsp32.Init()

	# process console commands
	while True :
		# show available console commands and get user input
		cmd = ShowConsoleCommands()

		if cmd == 'standby' :		# standby
			nsp32.Standby(0)

			print('-------------')
			print('standby ok')	
		elif cmd == 'wakeup' :		# wakeup
			nsp32.Wakeup()

			print('-------------')
			print('wakeup ok')	
		elif cmd == 'hello' :		# hello
			nsp32.Hello(0)

			print('-------------')
			print('hello ok')
		elif cmd == 'sensorid' :	# get sensor id
			nsp32.GetSensorId(0)

			print('-------------')
			print('sensor id = ' + nsp32.GetReturnPacket().ExtractSensorIdStr())
		elif cmd == 'wavelength' :	# get wavelength
			nsp32.GetWavelength(0)
			infoW = nsp32.GetReturnPacket().ExtractWavelengthInfo()

			print('-------------')
			print('num of points = ' + str(infoW.NumOfPoints))
			print('wavelength = ')
			print(infoW.Wavelength)
		elif cmd == 'spectrum' :	# spectrum acquisition
			nsp32.AcqSpectrum(0, 32, 3, False)	# integration time = 32; frame avg num = 3; disable AE

			# "AcqSpectrum" command takes longer time to execute, the return packet is not immediately available
			# when the acquisition is done, a "ready trigger" will fire, and nsp32.GetReturnPacketSize() will be > 0	
			while nsp32.GetReturnPacketSize() <= 0 :
				# TODO: can go to sleep or do other tasks here

				nsp32.UpdateStatus()	# call UpdateStatus() to check async result
	
			infoS = nsp32.GetReturnPacket().ExtractSpectrumInfo()

			print('-------------')
			print('integration time = ' + str(infoS.IntegrationTime))
			print('saturation flag = ' + str(infoS.IsSaturated))
			print('num of points = ' + str(infoS.NumOfPoints))
			print('spectrum = ')
			print([round(x, 6) for x in infoS.Spectrum])
			print('X, Y, Z = ', [round(x, 2) for x in [infoS.X, infoS.Y, infoS.Z]])
		elif cmd == 'xyz' :			# XYZ acquisition
			nsp32.AcqXYZ(0, 32, 3, False)		# integration time = 32; frame avg num = 3; disable AE

			# "AcqXYZ" command takes longer time to execute, the return packet is not immediately available
			# when the acquisition is done, a "ready trigger" will fire, and nsp32.GetReturnPacketSize() will be > 0	
			while nsp32.GetReturnPacketSize() <= 0 :
				# TODO: can go to sleep or do other tasks here

				nsp32.UpdateStatus()	# call UpdateStatus() to check async result
				
			infoXYZ = nsp32.GetReturnPacket().ExtractXYZInfo()
			
			print('-------------')
			print('integration time = ' + str(infoXYZ.IntegrationTime))
			print('saturation flag = ' + str(infoXYZ.IsSaturated))
			print('X, Y, Z = ', [round(x, 2) for x in [infoXYZ.X, infoXYZ.Y, infoXYZ.Z]])			
		elif cmd == 'exit' :
			break
		else:
			print('invalid command!')

def ShowConsoleCommands():
	"""show available console commands
	
	Returns:
		str: user input console command
	
	"""
	
	print('')
	print('***********************')
	print('1) standby - standby NSP32')
	print('2) wakeup - wakeup NSP32')
	print('3) hello - say hello to NSP32')
	print('4) sensorid - get sensor id string')
	print('5) wavelength - get wavelength')
	print('6) spectrum - start spectrum acquisition and get the result data')
	print('7) xyz - start XYZ acquisition and get the result data')
	print('8) exit - exit program')
	print('')
	return input('type an available command (case sensitive): ')


# start the program
try :
	main()
except Exception as e :
	print('error occurred: ' + str(e))
	print(traceback.format_exc())
