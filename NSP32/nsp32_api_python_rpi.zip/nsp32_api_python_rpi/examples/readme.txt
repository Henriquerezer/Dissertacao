﻿- Introduction
	There are two examples under this folder.
		1. Beginner
			A clean and simple example for beginners to start with NSP32. We'll demonstrate the basic usage of our API.
		2. ConsoleDemo
			A console program to demonstrate full functionalities of NSP32. Users can operate NSP32 by interactive console commands.
		3. SpectrumMeter
			A GUI program to visualize the spectrum measured by NSP32.

- *** hardware photos, screen shots ***

- Tested on
	Raspberry Pi 3 Model B with Rasbian Stretch version November 2018
	*** other RPi model or Rasbian version ***

- Hardware Setup
	The following tables show the recommended pin connections between NSP32 and RPi.

	1. VDD and GND
		----------------------------------------
		              NSP32         RPi
		Power         Pin           Pin         
		----------------------------------------
		              VDD3V3        3V3         
		              GND           GND         
		
	2. SPI signals (when data channel is SPI)
		----------------------------------------
		              NSP32         RPi
		SPI Signal    Pin           Pin         
		----------------------------------------
		Wakeup/Reset  RST           13 (the number is based on GPIO.BOARD)
		SPI SSEL      SS            SPI0_CE0_N
		SPI MOSI      MOSI          SPI0_MOSI
		SPI MISO      MISO          SPI0_MISO
		SPI SCK       SCK           SPI0_SCLK
		Ready         Ready         15 (the number is based on GPIO.BOARD)
		
	3. UART signals (when data channel is UART)
		----------------------------------------
		              NSP32         RPi
		UART Signal   Pin           Pin         
		----------------------------------------
		Wakeup/Reset  RST           13 (the number is based on GPIO.BOARD)
		UART RX       TX            UART0_RXD
		UART TX       RX            UART0_TXD
		Ready         Ready         15 (the number is based on GPIO.BOARD)

	4. If you are using NSP32 DBK board, make sure jumper J3 is ON (short).

- API Module Location
	Our API module file is put at [/examples/NanoLambdaNSP32.py].

- Software Setup
	1. Install Python 3.5 or above (Python 2 doesn't work).
	
	2. The examples and the API utilizes the following modules, please make sure they are installed under your environment.
		(1) RPi.GPIO [https://pypi.org/project/RPi.GPIO/]
		(2) spidev [https://pypi.org/project/spidev/]
		(3) pySerial [https://pypi.org/project/pyserial/]

	3. The "SpectrumMeter" example utilizes additional packages for GUI and plotting, please make sure the followings are installed under your environment.
		(1) tkinter
		(2) matplotlib
		
		Note: You might also need to upgrade the "numpy" package to the latest version.

	4. Make sure to enable SPI on RPi by the following steps.
		(1) Use the terminal command:
				$ sudo raspi-config 
		(2) Under the Software Configuration Tool, select:
				Interfacing Options > SPI > Yes > Ok.

	5. Make sure to enable UART (disable serial login shell, enable serial interface) on RPi by the following steps.
		(1) Use the terminal command:
				$ sudo raspi-config 
		(2) Under the Software Configuration Tool, select:
				Interfacing Options > Serial > No > Yes > Ok.

- Customization
	Source code modification is required if you want to change the pin numbers or the data channel type (default to SPI).
	For your convenience, we have marked that code section with the title "modify this section to fit your need".

- Run the Example
	To run the examples, use Python commands:
		$ python3 Beginner.py
		$ python3 ConsoleDemo.py
		$ python3 SpectrumMeter.py

	*** operations & behaviors (including the LED status, etc...) ***
