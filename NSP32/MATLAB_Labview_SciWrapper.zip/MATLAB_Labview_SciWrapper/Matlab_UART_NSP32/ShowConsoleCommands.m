function [] = ShowConsoleCommands()
%SHOWCONSOLECOMMANDS Summary of this function goes here
%   Detailed explanation goes here
disp("");
disp("***********************");
disp("1) sensorid - get sensor id string");
disp("2) wavelength - get wavelength");
disp("3) spectrum - start spectrum acquisition and get the result data");
disp("4) xyz - start XYZ acquisition and get the result data");
disp("5) exit - exit program");
disp("");
end

