% include lib
NET.addAssembly([cd '\Scilib\NanoLambdaSciLib.dll']);
% instance 
nsp32 = NanoLambdaSciLib.NSP32SciWrapper();
% Open serial port
nsp32.Open("COM25")
while 1
    % show available console commands
    ShowConsoleCommands();
    command=input('type an available command (case sensitive): ', 's');
    switch command
        case 'sensorid'
            SensorId=nsp32.GetSensorId().string;
            fprintf('SensorId: %s \n',SensorId);
        case 'wavelength'
            infoW=nsp32.GetWavelength();
            fprintf('#points: %d \n',infoW.NumOfPoints);
            fprintf('Wavelength: \n');
            fprintf('%d, ',infoW.Wavelength.uint16);
            %fprintf('%d, ',infoW.Wavelength.double);
            fprintf('\n')
        case 'spectrum'
            infoS=nsp32.AcqSpectrum(32, 3, false);
            fprintf('#points: %d \n',infoS.NumOfPoints);
            fprintf('IntegrationTime: %d \n',infoS.IntegrationTime);
            fprintf('IsSaturated: %d \n',infoS.IsSaturated);
            fprintf('Spectrum: \n');
            fprintf('%f, ',infoS.Spectrum.double);
            fprintf('\n')
            fprintf('XYZ: (%f, %f, %f) \n',infoS.X,infoS.Y,infoS.Z);
        case 'xyz'
            infoXYZ=nsp32.AcqXYZ(32, 3, false);
            fprintf('IntegrationTime: %d \n',infoXYZ.IntegrationTime);
            fprintf('IsSaturated: %d\n',infoXYZ.IsSaturated);
            fprintf('XYZ: (%f, %f, %f) \n',infoXYZ.X,infoXYZ.Y,infoXYZ.Z);
        case 'exit'
            % close serial port
            nsp32.Close();
            break;
        otherwise
            disp('invaild command');
    end
end